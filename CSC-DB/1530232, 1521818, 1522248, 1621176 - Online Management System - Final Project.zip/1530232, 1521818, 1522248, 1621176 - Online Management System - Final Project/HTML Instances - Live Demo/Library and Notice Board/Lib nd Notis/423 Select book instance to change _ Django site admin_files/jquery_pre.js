var _djdt_define_amd_backup;
if (window.define) {
    _djdt_define_amd_backup = window.define.amd;
    window.define.amd = undefined;
}
