from django.apps import AppConfig


class MessageBoardConfig(AppConfig):
    name = 'message_board'
