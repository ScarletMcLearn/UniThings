﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test_calc
{
    public partial class Form1 : Form
    { 
        string op = "";
        double value = 0;
        bool clicked = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (clicked || label1.Text == "0")
            {
                label1.Text = "";
                
            }
            Button b = (Button)sender;
            clicked = false;
            label1.Text = label1.Text + b.Text;
            
        }

        private void op_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            op = b.Text;
            value = Double.Parse(label1.Text);
            clicked = true;
            eq.Text = value + " " + op;

        }

        private void equals_Click(object sender, EventArgs e)
        {
            eq.Text = "";
            switch (op) {
                case "+":
                    label1.Text = 
                        (value + Double.Parse(label1.Text)).ToString();
                    break;

                case "-":
                    label1.Text =
                        (value - Double.Parse(label1.Text)).ToString();
                    break;

                case "*":
                    label1.Text =
                        (value * Double.Parse(label1.Text)).ToString();
                    break;

                case "/":
                    label1.Text =
                        (value * Double.Parse(label1.Text)).ToString();
                    break;


            }
        }
    }
}
