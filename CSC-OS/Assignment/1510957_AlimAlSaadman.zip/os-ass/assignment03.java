/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.concurrent.atomic.AtomicInteger;

/**
 *
 * @author Nayem
 */
public class assignment03 {

    public static void main(String[] args) {
        AtomicInteger counter = new AtomicInteger(0);
        int n = Integer.parseInt(args[0]);

        for(int i=0; i<n; i++){
            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    for(int i=0; i<50000; i++){
                        counter.addAndGet(1);
                    }
                    System.out.println("Counter = "+String.valueOf(counter.get()));
                }
            });
            t.start();
        }
    }
}
// PS > java -jar .\OS_ASS_03.jar 2
// Counter = 20000
// Counter = 20000
// PS > java -jar .\OS_ASS_03.jar 4
// Counter = 40000
// Counter = 40000
// Counter = 40000
// Counter = 40000
// PS > java -jar .\OS_ASS_03.jar 8
// Counter = 38013
// Counter = 40259
// Counter = 40259
// Counter = 37988
// Counter = 69894
// Counter = 72657
// Counter = 74895
// Counter = 80000
