#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include<iostream>
using namespace std;

int* n;

int main(){
    // create shared memory for 14 int variables
    // first 2 ints for flags abReady, cReady
    // next 12 for keeping the 3 2x2 matrices
    n = (int*)mmap(NULL, sizeof(int)*14,
        PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
        
    int* abReady = n;
    int* cReady = n+1;
    int* a = cReady+1;
    int* b = a+4;
    int* c = b+4;
    
    
    int pid = fork();
    if(pid==0){ //it's the child
        *abReady = 0;
        *cReady = 0;
        cout<<"[CHILD]"<<endl;
        cout<<"Enter matrix A's elements (4 inputs): ";
        cin>>a[0]>>a[1]>>a[2]>>a[3];
        cout<<"Enter matrix B's elements (4 inputs): ";
        cin>>b[0]>>b[1]>>b[2]>>b[3];
        
        cout<<"Matrix A:\n"<<a[0]<<" "<<a[1]<<"\n"<<a[2]<<" "<<a[3]<<"\n";
        cout<<"Matrix B:\n"<<b[0]<<" "<<b[1]<<"\n"<<b[2]<<" "<<b[3]<<"\n";
        
        *abReady = 1;
        
        while(!*cReady) sleep(5);
        cout<<"[CHILD]"<<endl;
        cout<<"Matrix C:\n"<<c[0]<<" "<<c[1]<<"\n"<<c[2]<<" "<<c[3]<<"\n";
        exit(0);
    }else{ // its the parent
        while(!*abReady) sleep(5);
        
        cout<<"[PARENT] (calculating c = a * b)"<<endl;
        c[0] = a[0]*b[0] + a[1]*b[2];
        c[1] = a[0]*b[1] + a[1]*b[3];
        c[2] = a[2]*b[0] + a[3]*b[2];
        c[3] = a[2]*b[1] + a[3]*b[3];
        
        *cReady = 1;
        wait(0);
    }
    
    exit(0);
}