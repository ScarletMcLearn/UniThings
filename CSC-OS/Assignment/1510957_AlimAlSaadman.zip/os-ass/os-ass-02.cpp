#include<stdio.h>
#include<unistd.h>
#include<cstdlib>
#include<cstring>
using namespace std;

int* n;

int main(){

    int pipeA[2], a;
    int pipeB[2], b;
    int pipeC[2], c;
    a = pipe(pipeA);
    b = pipe(pipeB);
    c = pipe(pipeC);

    if(a == -1) printf("pipe A failed!\n");
    else printf("pipe A made!\n");

    if(b == -1) printf("pipe B failed!\n");
    else printf("pipe B made!\n");

    if(c == -1) printf("pipe C failed!\n");
    else printf("pipe C made!\n");

    char *line0 = "hello! this is line 0!";
    char *line1 = "#";
    char *line2 = "this is line  2!";

    int pA = fork();
    if(pA==0){ //it's child A
        close(pipeA[0]);
        for(int i=0; i<strlen(line0); i++){
            if(line0[i]=='#') break;
            write(pipeA[1], line0+i, 1);
        }
        close(pipeA[1]);
        exit(0);
    }
    int pB = fork();
    if(pB==0){ //it's child B

        close(pipeB[0]);
        for(int i=0; i<strlen(line1); i++){
            if(line1[i]=='#') break;
            write(pipeB[1], line1+i, 1);
        }
        close(pipeB[1]);
        exit(0);
    }

    else{ // its the parent
        int pC = fork();
        if(pC==0){ // it's child C
        close(pipeC[0]);
        for(int i=0; i<strlen(line2); i++){
            if(line1[i]=='#') break;
            write(pipeC[1], line2+i, 1);
        }
        close(pipeC[1]);
        exit(0);
        }else{ // its the parent
            close(pipeA[1]);
            close(pipeB[1]);
            close(pipeC[1]);
            char buf;

            printf("[parent] reading pipe A\n");
            while(read(pipeA[0], &buf, 1) > 0) printf("%c",buf);
            close(pipeA[0]);

            printf("\n");
            printf("[parent] reading pipe B\n");
            while(read(pipeB[0], &buf, 1) > 0) printf("%c",buf);
            close(pipeB[0]);

            printf("\n");
            printf("[parent] reading pipe C\n");
            while(read(pipeC[0], &buf, 1) > 0) printf("%c",buf);
            close(pipeC[0]);
        }
    }

    exit(0);
}
