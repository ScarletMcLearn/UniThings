#include<iostream>
#include<cstdlib>
#include<pthread.h>
#include<semaphore.h>
using namespace std;

#define NUM_THREADS 10

sem_t rw_mutex;
sem_t mutex;
int readers = 0;

int data = 25;

void *write(void *t){
    sem_wait(&rw_mutex);
    
    cout<<"[WRITER t="<<t<<"] writing data = "<<data;
    for(int i=0; i<rand()%NUM_THREADS; i++) cout<<">"<<++data;
    cout<<" end!"<<endl;
    
    sem_post(&rw_mutex);
}

void *read(void *t){
    sem_wait(&mutex);
    readers++;
    
    if(readers == 1) sem_wait(&rw_mutex);
    sem_post(&mutex);
    
    cout<<"[READER t="<<t<<"] reading data = "<<data;
    for(int i=0; i<rand()%NUM_THREADS; i++) cout<<"."<<data;
    cout<<" end!"<<endl;
    
    sem_wait(&mutex);
    readers--;
    if(readers == 0) sem_post(&rw_mutex);
    sem_post(&mutex);
}

int main(){
    if(sem_init(&rw_mutex, 0, 1) == -1) cout<<"SEM rw_mutex error!"<<endl;
    if(sem_init(&mutex, 0, 1) == -1) cout<<"SEM mutex error!"<<endl;
    
    
    int rc; long t;
    const int WRITER = rand()%NUM_THREADS;
    cout<<"Write ID: "<<WRITER<<endl;
    
    pthread_t threads[NUM_THREADS];
    
    for(t=0;t<NUM_THREADS;t++){
        cout<<"creating thread "<<t<<endl;
        if(t==WRITER) rc = pthread_create(&threads[t], NULL, write, (void *)t);
        else rc = pthread_create(&threads[t], NULL, read, (void *)t);
        if (rc){
            cout<<"ERROR; return code from pthread_create() is "<<rc<<endl;
            exit(-1);
        }
    }

   
    pthread_exit(NULL);
    
    return 0;
}