#include<iostream>
#include<cstdlib>
#include<pthread.h>
#include<semaphore.h>
using namespace std;

#define NUM_BUFFER 10
#define NUM_THREAD 2
#define LIMIT 10

sem_t mutex;
sem_t empty;
sem_t full;

int* buffer = new int[NUM_BUFFER];
int offset = 0;

int production_count = LIMIT;
int consumption_count = 0;


void *produce(void *t){
    do{
        int data = rand()%100;
        cout<<"[PRODUCER t="<<t<<"] produced data = "<<data<<endl;
        production_count--;
        
        sem_wait(&empty);
        sem_wait(&mutex);
        
        cout<<"[PRODUCER t="<<t<<"] adding data = "<<data<<endl;
        buffer[offset++] = data;
        
        sem_post(&mutex);
        sem_post(&full);
    }while(production_count>0);
    
}

void *consume(void *t){
    do{
        sem_wait(&full);
        sem_wait(&mutex);
        
        int data = buffer[offset--];
        cout<<"[CONSUMER t="<<t<<"] removed data = "<<data<<endl;
        
        sem_post(&mutex);
        sem_post(&empty);
        
        cout<<"[CONSUMER t="<<t<<"] consuming data = "<<data<<endl;
        consumption_count++;

    }while(consumption_count<LIMIT);
}

int main(){
    if(sem_init(&mutex, 0, 1) == -1) cout<<"SEM mutex error!"<<endl;
    if(sem_init(&empty, 0, NUM_BUFFER) == -1) cout<<"SEM empty error!"<<endl;
    if(sem_init(&full, 0, 0) == -1) cout<<"SEM full error!"<<endl;
    
    
    int rc; long t;
    
    pthread_t threads[NUM_THREAD];
    
    for(t=0;t<NUM_THREAD;t++){
        cout<<"creating thread "<<t<<endl;
        if(t%2==0) rc = pthread_create(&threads[t], NULL, produce, (void *)t);
        else rc = pthread_create(&threads[t], NULL, consume, (void *)t);
        if (rc){
            cout<<"ERROR; return code from pthread_create() is "<<rc<<endl;
            exit(-1);
        }
    }

   
    pthread_exit(NULL);
    
    return 0;
}