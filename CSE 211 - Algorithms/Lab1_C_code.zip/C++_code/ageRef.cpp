#include <iostream>

using namespace std;

void chAge(int &ageRef)
{
	cout << &ageRef << endl;
	
	ageRef = 18;
}

int main()
{
	int myage = 30;
	int myage1 = 40;
	
	cout << &myage << endl; cout << myage << endl; 
	cout << &myage1 << endl; cout << myage1 << endl;
	
	chAge(myage); chAge(myage1);
	
	cout << &myage << endl; cout << myage << endl;
	cout << &myage1 << endl; cout << myage1 << endl;
	
	return 0;
}
