#include <iostream>

using namespace std; 

int main()
{
	int arr[5];
	int i;
	
	for(i = 0; i < 5; ++i)
		arr[i] = i + 1;
		
	for(i = 0; i < 5; ++i)
	{
		cout << "value: " << arr[i] << " "
		<< "value by deref: " << *(arr + i) << " "
		<<"address by ref: " << &arr[i] << " "
        <<"address by first ref: " << arr + i;
			
        cout << endl;
    }
	
	return 0;
}
