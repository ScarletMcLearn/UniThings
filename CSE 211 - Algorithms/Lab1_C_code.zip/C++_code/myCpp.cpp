#include <stdio.h>

int main()
{
	printf("C is a subset of C++, QED\n");
	
	return 0;
}
