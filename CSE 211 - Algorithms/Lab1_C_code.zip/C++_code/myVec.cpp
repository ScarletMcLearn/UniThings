#include <iostream>
#include <vector>

using namespace std;

int main()
{
	vector <int> myVec(10);
	int myArr[5] = {1, 2, 3, 4, 5};
	
	myVec.insert(myVec.begin(), myArr, myArr+5);
	
	for(int i = 0; i < 5; ++i)
	{
		cout << myVec.at(i) << endl;
	}
	
	cout << myVec.size() << endl;
	
	myVec.push_back(13);
	
	cout << myVec.back() << endl;
	
	cout << myVec.size() << endl;
	
	myVec.pop_back();
	
	cout << myVec.back() << endl;
	
	cout << myVec.size() << endl;
	
	myVec.insert(myVec.begin() + 5, 71);
	
	cout << myVec.at(5) << endl;
	 
	return 0;
}
