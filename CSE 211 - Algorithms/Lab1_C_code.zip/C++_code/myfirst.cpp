#include <iostream>

using namespace std;

int main()
{
	cout << "Hello Class" << endl;
	cout << "I am Bijoy arif" << endl;
	
	int num1, num2, sum;
	
	cin >> num1; cin >> num2;
	
	sum = num1 + num2;
	
	cout << "the sum is = " << sum << endl;
	
	int num[5] = { 1, 2, 3, 4, 5};
	
	for(int i = 0; i < 5; ++i)
		cout << num[i] << endl;
	
	return 0;
}
