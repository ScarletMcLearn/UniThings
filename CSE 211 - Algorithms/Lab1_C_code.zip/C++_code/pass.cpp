#include <iostream> 

using namespace std;

int passbyval(int x, int y)
{
	int tmp;
	tmp = x;
	x = y;
	y = tmp;
}

int passbyref(int *x, int *y)
{
	int tmp;
	tmp = *x;
	*x = *y;
	*y = tmp;
}

int main()
{
	int a , b;
	
	cin >> a; cin >> b;
	
	passbyval(a, b);
	
	cout << "after calling pass by value " << a << " " << b << endl;
	
	passbyref(&a, &b);
	
	cout << "after calling pass by reference " << a << " " << b << endl;

    cout << "address a: " << &a << endl; cout << "address b: " << &b << endl;
    
} 
