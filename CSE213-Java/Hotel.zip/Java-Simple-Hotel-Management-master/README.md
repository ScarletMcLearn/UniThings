# Java-Simple-Hotel-Management#

This was an experimental project built for a demo. It has almost all the features roughly required to manage a hotel.

**Disclaimer**

The complete project was built when I was a novice student of Java. You are strongly discouraged to use it as it now.
There is only one purpose of releasing it publicly. It is to get the idea of how different components of Java Swing, other UI Library & also SQLite work together. I know the codebase is somewhere messy & somewhere organized. That's because it was an experiment with no supervision.

But Newbies & students are encouraged explore the codebase. Specially when you are assigned to do some management system by your faculty with no guidelines. Tried to write comment where i felt necesary back then. If you can understand properly and make some improvements, Kudos :)

There are also some test files which are called in no where. so ignore those parts.

The project was created using Java 7.** and IDE used was Netbeans 7. The Visual parts were done through Netbeans drag & drop tools.


*Project Overview*
You need to create `user/guest/visitor and least one room class & a room` first from the dashboard before you see it in action. After that Search the employee name. ( you need to write at least 3 characters before the suggestion appears). Click room and make the booking.

And from the `Booking Dairy` Menu you'll be able to search by the room name and add different orders associated with that booking/visitor.

`Checkout&Payment` also works in similar fashion. search by room name, explicitly check out them by clicking it and then generate payment & print. ( the most undone part is this section). you'll see the printing pdf has merely anything but the table. It's still a good idea to see the code to understand how to initate this things.


![Alt text](https://s32.postimg.org/4hbw178qt/hotel_management.png "Optional title")
