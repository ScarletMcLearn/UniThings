#include<iostream>
#include<cstdlib>
#include<string>
#include"stack.cpp"
#include"queue.cpp"


using namespace std;

class Sentence{

public:
    void SeparateCaseAndDisplay(string s)
    {
        Stack stk(50);
        Queue q(50);
        double stkVal, qVal;

        int i, n;
        n=s.length();
        for(i=0;i<n;i++)
        {
            if(s[i]>='A'&&s[i]<='Z')
            stk.Push(s[i]);
            else if(s[i]>='a'&&s[i]<='z')
            q.Enqueue(s[i]);
        }
        cout<<endl;
        while(!stk.IsEmpty())
        {
            stkVal=stk.Pop();
            cout<<(char)stkVal;
        }
        cout<<endl;
        while(!q.IsEmpty())
        {
            q.Dequeue(qVal);
            cout<<(char)qVal;
        }
     }




};


int main(void) {
string s;
Sentence obj;
cout<<"Enter a string: "<<endl;
getline(cin,s);
obj.SeparateCaseAndDisplay(s);




return 0;
}
